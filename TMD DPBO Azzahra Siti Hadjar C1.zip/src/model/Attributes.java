/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/*
 *	Filename	= Attributes.java
 *	Author		= Azzahra Siti Hadjar
 *	NIM		= 2100901 
 *      Email           = azzahrasth@upi.edu
 *	Deskripsi 	= model untuk menyimpan atribut global
 */

package model;

/**
 *
 * @author sitih
 */

public class Attributes {
    public static class attribute{
        public static final float gameSpeed = 2f; // kecepatan game
        public static final int gameWidth = 800; // lebar game
        public static final int gameHeight = 650; // tinggi game
    }
}
